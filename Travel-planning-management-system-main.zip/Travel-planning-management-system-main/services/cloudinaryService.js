const { cloudinary } = require("../cloudConfig.js");

const hasCloudinaryConfig = () => process.env.CLOUD_NAME && process.env.CLOUD_API_KEY && process.env.CLOUD_API_SECRET;

const destroyAsset = async (filename) => {
    if (!filename || !hasCloudinaryConfig()) return;
    await cloudinary.uploader.destroy(filename);
};

module.exports = {
    destroyAsset,
    hasCloudinaryConfig,
};
