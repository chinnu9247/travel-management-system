import { useEffect, useState } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { api } from "../api";
import { BackButton } from "../components/Layout.jsx";
import useValidation from "../hooks/useValidation";

const fallbackImage = "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=800&q=60";
const categories = [
    ["amazing-views", "Amazing Views"],
    ["trending", "Trending"],
    ["bed-and-breakfasts", "Bed & Breakfasts"],
    ["arctic", "Arctic"],
    ["camping", "Camping"],
    ["amazing-pools", "Amazing Pools"],
    ["castles", "Castles"],
];

export default function ListingForm({ mode, currentUser, showError }) {
    const { id } = useParams();
    const navigate = useNavigate();
    const validate = useValidation();
    const [listing, setListing] = useState(null);
    const [selectedImagePreview, setSelectedImagePreview] = useState("");

    useEffect(() => {
        if (mode === "edit") {
            api.listing(id)
                .then((data) => setListing(data.listing))
                .catch((error) => {
                    showError(error.message);
                    navigate("/listings");
                });
        }
    }, [id, mode]);

    const isEdit = mode === "edit";
    const isUnauthorizedEdit = isEdit && listing?.owner?._id && listing.owner._id !== currentUser?._id;

    useEffect(() => {
        if (isUnauthorizedEdit) showError("You are not authorized to make changes.");
    }, [isUnauthorizedEdit]);

    if (!currentUser) return <Navigate to="/login" replace />;
    if (mode === "edit" && !listing) return null;

    if (isUnauthorizedEdit) {
        return <Navigate to={`/listings/${id}`} replace />;
    }

    const previewImage = selectedImagePreview || listing?.image?.url?.replace("/upload", "/upload/c_auto,h_200,w_400") || fallbackImage;

    const handleImageChange = (event) => {
        const file = event.target.files?.[0];
        setSelectedImagePreview(file ? URL.createObjectURL(file) : "");
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (!validate(event)) return;

        try {
            const formData = new FormData(event.currentTarget);
            const data = isEdit ? await api.updateListing(id, formData) : await api.createListing(formData);
            navigate(data.redirect || (isEdit ? `/listings/${id}` : "/listings"));
        } catch (error) {
            showError(error.message);
        }
    };

    return (
        <>
            <BackButton to={isEdit ? `/listings/${id}` : "/listings"} />

            <div className="row justify-content-center">
                <div className="col-12 col-lg-10 col-xl-8">
                    <div className={`${isEdit ? "border border-dark rounded-2" : "border border-secondary rounded-3"} border-2 my-4 p-3 p-md-5 bg-light form-panel`}>
                        <h3 className="mb-4 fw-bold">{isEdit ? "Edit your Listing" : "Create New Listing"}</h3>

                        <form onSubmit={handleSubmit} className="needs-validation" encType="multipart/form-data" noValidate>
                            <div className="mb-4">
                                <label htmlFor="title" className="form-label fw-bold">
                                    Title
                                </label>
                                <input
                                    type="text"
                                    name="listing[title]"
                                    id="title"
                                    defaultValue={listing?.title || ""}
                                    placeholder={isEdit ? undefined : "Give title to your place"}
                                    className="form-control border border-2 border-secondary-subtle"
                                    required
                                />
                                <div className="invalid-feedback">Title required!</div>
                            </div>

                            <div className="mb-4">
                                <label htmlFor="description" className="form-label fw-bold">
                                    Description
                                </label>
                                <textarea
                                    name="listing[description]"
                                    id="description"
                                    defaultValue={listing?.description || ""}
                                    placeholder={isEdit ? undefined : "Short description of your place"}
                                    className="form-control border border-2 border-secondary-subtle"
                                    required
                                ></textarea>
                                <div className="invalid-feedback">Enter short description!</div>
                            </div>

                            <div className={isEdit ? "mb-4" : "mb-4"}>
                                <label htmlFor="image" className="form-label fw-bold">
                                    {isEdit ? "Upload New Image" : "Upload Listing Image"}
                                </label>
                                <input
                                    type="file"
                                    name="listing[image]"
                                    id="image"
                                    className="form-control border border-2 border-secondary-subtle"
                                    accept="image/*"
                                    onChange={handleImageChange}
                                    required={!isEdit}
                                />
                            </div>

                            {(isEdit || selectedImagePreview) && (
                                <div className="mb-4">
                                    <label className="form-label fw-bold">{selectedImagePreview ? "Selected Image Preview" : "Image Preview"}</label>
                                    <img src={previewImage} className="card-img-top object-fit-cover show-img" alt="Listing preview" />
                                </div>
                            )}

                            <div className="row">
                                <div className="mb-4 col-md-4">
                                    <label htmlFor="price" className="form-label fw-bold">
                                        Price
                                    </label>
                                    <input
                                        type="number"
                                        name="listing[price]"
                                        id="price"
                                        defaultValue={listing?.price || ""}
                                        placeholder={isEdit ? undefined : "1500"}
                                        className="form-control border border-2 border-secondary-subtle"
                                        required
                                    />
                                    <div className="invalid-feedback">Enter valid price!</div>
                                </div>

                                <div className="mb-4 col-md-8">
                                    <label htmlFor="country" className="form-label fw-bold">
                                        Country
                                    </label>
                                    <input
                                        type="text"
                                        name="listing[country]"
                                        id="country"
                                        defaultValue={listing?.country || ""}
                                        placeholder={isEdit ? undefined : "India"}
                                        className="form-control border border-2 border-secondary-subtle"
                                        required
                                    />
                                    {isEdit && <div className="invalid-feedback">Enter valid country name!</div>}
                                </div>
                                {!isEdit && <div className="invalid-feedback">Enter valid country name!</div>}
                            </div>

                            <div className="mb-4">
                                <label htmlFor="category" className="form-label fw-bold">
                                    Category
                                </label>
                                <select
                                    name="listing[category]"
                                    id="category"
                                    defaultValue={listing?.category || "amazing-views"}
                                    className="form-select border border-2 border-secondary-subtle"
                                    required
                                >
                                    {categories.map(([value, label]) => (
                                        <option value={value} key={value}>
                                            {label}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div className="mb-4">
                                <label htmlFor="location" className="form-label fw-bold">
                                    Location
                                </label>
                                <input
                                    type="text"
                                    name="listing[location]"
                                    id="location"
                                    defaultValue={listing?.location || ""}
                                    placeholder={isEdit ? undefined : "Mumbai, India"}
                                    className="form-control border border-2 border-secondary-subtle"
                                    required
                                />
                                <div className="invalid-feedback">Enter valid location!</div>
                            </div>

                            <button className={`btn ${isEdit ? "btn-dark edit-listing-btn" : "btn-primary add-new-listing-btn"} w-100 fw-bold border-0`}>
                                {isEdit ? "Edit" : "Add"}
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
}
