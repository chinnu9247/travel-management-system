import { Link, useNavigate, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { Fragment } from "react";
import { api } from "../api";
import { BackButton } from "../components/Layout.jsx";
import useValidation from "../hooks/useValidation";

const fallbackImage = "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=1200&q=60";

export default function ListingShow({ currentUser, refreshSession, refreshNotifications, showError }) {
    const { id } = useParams();
    const navigate = useNavigate();
    const validate = useValidation();
    const [listing, setListing] = useState(null);
    const [bookingMessage, setBookingMessage] = useState("");

    const loadListing = () => api.listing(id).then((data) => setListing(data.listing));

    useEffect(() => {
        loadListing().catch((error) => {
            showError(error.message);
            navigate("/listings");
        });
    }, [id]);

    if (!listing) {
        return (
            <>
                <BackButton to="/listings" />
                <div className="text-center text-secondary my-5">
                    <i className="fa-solid fa-spinner fa-spin me-2"></i>
                    Loading listing...
                </div>
            </>
        );
    }

    const isOwner = currentUser && listing.owner && currentUser._id === listing.owner._id;
    const reviews = listing.reviews || [];
    const averageRating = reviews.length
        ? reviews.reduce((sum, review) => sum + Number(review.rating || 0), 0) / reviews.length
        : 0;

    const handleDeleteListing = async (event) => {
        event.preventDefault();
        try {
            await api.deleteListing(listing._id);
            navigate("/listings");
        } catch (error) {
            showError(error.message);
        }
    };

    const handleReviewSubmit = async (event) => {
        event.preventDefault();
        if (!validate(event)) return;

        const form = event.currentTarget;
        const formData = new FormData(form);
        try {
            await api.createReview(listing._id, {
                review: {
                    rating: formData.get("review[rating]"),
                    comment: formData.get("review[comment]"),
                },
            });
            form.reset();
            await refreshSession();
            loadListing();
        } catch (error) {
            showError(error.message);
        }
    };

    const handleBookingSubmit = async (event) => {
        event.preventDefault();
        if (!validate(event)) return;

        const form = event.currentTarget;
        const formData = new FormData(form);

        try {
            const data = await api.createBooking(listing._id, {
                booking: {
                    checkIn: formData.get("booking[checkIn]"),
                    checkOut: formData.get("booking[checkOut]"),
                    guests: formData.get("booking[guests]"),
                },
            });
            const total = Number(data.booking.totalPrice || 0).toLocaleString("en-IN");
            setBookingMessage(`Booking confirmed. Total price: Rs. ${total}`);
            form.reset();
            await refreshSession();
            await refreshNotifications();
        } catch (error) {
            showError(error.message);
        }
    };

    const handleDeleteReview = async (reviewId) => {
        try {
            await api.deleteReview(listing._id, reviewId);
            await refreshSession();
            loadListing();
        } catch (error) {
            showError(error.message);
        }
    };

    return (
        <>
            <BackButton to="/listings" />

            <div className="row">
                <div className="col-12 col-lg-10 offset-lg-1">
                    <h3 className="fw-bold">{listing.title}</h3>
                </div>

                <div className="col-12 col-lg-10 offset-lg-1 my-2 mb-4">
                    <img src={listing.image?.url || fallbackImage} className="card-img-top object-fit-cover show-img" alt={listing.title || "Listing image"} />
                    <div className="card-body mx-2">
                        <p className="card-text text-light-emphasis mt-2">{listing.description}</p>
                        <p className="card-text">&#8377; {Number(listing.price).toLocaleString("en-IN")}</p>
                        <p className="card-text">
                            {listing.location}, {listing.country}.
                        </p>

                        {!isOwner && (
                            <div className="booking-panel my-4">
                                <div className="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
                                    <div>
                                        <h4 className="fs-5 fw-bold mb-1">Book this trip</h4>
                                        <small className="text-secondary">&#8377; {Number(listing.price || 0).toLocaleString("en-IN")} per guest per night</small>
                                    </div>
                                    {!currentUser && (
                                        <Link to="/login" className="btn btn-outline-dark align-self-md-start">
                                            Login to book
                                        </Link>
                                    )}
                                </div>

                                {currentUser && (
                                    <form onSubmit={handleBookingSubmit} className="needs-validation booking-form" noValidate>
                                        <div className="row g-3">
                                            <div className="col-12 col-md-4">
                                                <label htmlFor="checkIn" className="form-label fw-semibold">Check-in</label>
                                                <input type="date" id="checkIn" name="booking[checkIn]" className="form-control" required />
                                                <div className="invalid-feedback">Choose a check-in date.</div>
                                            </div>
                                            <div className="col-12 col-md-4">
                                                <label htmlFor="checkOut" className="form-label fw-semibold">Check-out</label>
                                                <input type="date" id="checkOut" name="booking[checkOut]" className="form-control" required />
                                                <div className="invalid-feedback">Choose a check-out date.</div>
                                            </div>
                                            <div className="col-12 col-md-2">
                                                <label htmlFor="guests" className="form-label fw-semibold">Guests</label>
                                                <input type="number" id="guests" name="booking[guests]" className="form-control" min="1" max="20" defaultValue="1" required />
                                                <div className="invalid-feedback">Add guests.</div>
                                            </div>
                                            <div className="col-12 col-md-2 d-flex align-items-end">
                                                <button className="btn booking-submit w-100">Book</button>
                                            </div>
                                        </div>
                                        {bookingMessage && <div className="alert alert-success mt-3 mb-0">{bookingMessage}</div>}
                                    </form>
                                )}
                            </div>
                        )}

                        {isOwner && (
                            <form onSubmit={handleDeleteListing} className="listing-actions">
                                <Link to={`/listings/${listing._id}/edit`} className="btn btn-dark border-0 px-5">
                                    Edit
                                </Link>
                                <button className="btn btn-danger px-5">Delete</button>
                            </form>
                        )}
                        <hr />
                        <small className="card-text">Hosted by {listing.owner?.username}</small>
                    </div>
                </div>

                {currentUser && (
                    <>
                        <hr />
                        <div className="col-12 col-lg-10 offset-lg-1 mb-3">
                            <h4 className="mb-0 fs-4">
                                <b>Rate this place</b>
                            </h4>
                            <small className="text-secondary">Tell others what you think.</small>
                            <form onSubmit={handleReviewSubmit} className="needs-validation review-form" noValidate>
                                <div className="mb-3 mt-4">
                                    <label htmlFor="rating" className="form-label fw-bold fs-5 m-0">
                                        Rating
                                    </label>
                                    <fieldset className="starability-basic">
                                        <input type="radio" id="no-rate" className="input-no-rate" name="review[rating]" value="1" defaultChecked aria-label="No rating." />
                                        {[1, 2, 3, 4, 5].map((rating) => (
                                            <Fragment key={rating}>
                                                <input type="radio" id={`first-rate${rating}`} name="review[rating]" value={rating} />
                                                <label htmlFor={`first-rate${rating}`} title={["Terrible!", "Not good!", "Average!", "Very good!", "Amazing!"][rating - 1]}>
                                                    {rating} star{rating > 1 ? "s" : ""}
                                                </label>
                                            </Fragment>
                                        ))}
                                    </fieldset>
                                </div>
                                <div className="mb-3 mt-4">
                                    <label htmlFor="review" className="form-label fw-bold fs-5 m-0">
                                        Review
                                    </label>
                                    <textarea
                                        name="review[comment]"
                                        id="review"
                                        className="form-control border-2 border-success"
                                        placeholder="Describe your experience"
                                        rows="2"
                                        required
                                    ></textarea>
                                    <div className="invalid-feedback">Please add some comment to submit review!</div>
                                </div>
                                <button className="btn btn-outline-success fw-bold border-2 px-5 review-submit">Submit</button>
                            </form>
                        </div>
                    </>
                )}

                <div className="col-12 col-lg-10 offset-lg-1 mb-3">
                    <hr />
                    <h4 className="fs-4">
                        <b>Rating and reviews</b>
                    </h4>
                    {reviews.length > 0 ? (
                        <div className="d-flex align-items-center mb-2">
                            {Array.from({ length: Math.round(averageRating) }).map((_, index) => (
                                <Star filled key={`average-filled-${index}`} />
                            ))}
                            {Array.from({ length: 5 - Math.round(averageRating) }).map((_, index) => (
                                <Star key={`average-empty-${index}`} />
                            ))}
                            <small className="ms-2">
                                {averageRating.toFixed(1)} average from {reviews.length} review{reviews.length === 1 ? "" : "s"}
                            </small>
                        </div>
                    ) : (
                        <small className="text-secondary">No reviews yet.</small>
                    )}
                    <div className="row g-3">
                        {reviews.map((review) => (
                            <ReviewCard
                                key={review._id}
                                review={review}
                                currentUser={currentUser}
                                onDelete={() => handleDeleteReview(review._id)}
                            />
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
}

function ReviewCard({ review, currentUser, onDelete }) {
    const isAuthor = currentUser && review.author && currentUser._id === review.author._id;

    return (
        <div className="col-12 col-md-6">
            <div className="card review-card h-100 py-2">
            <div className="card-body d-flex flex-column justify-content-between">
                <h5 className="card-title fw-bold">@{review.author?.username}</h5>
                <div className="d-flex align-items-center">
                    {Array.from({ length: Number(review.rating) }).map((_, index) => (
                        <Star filled key={`filled-${index}`} />
                    ))}
                    {Array.from({ length: 5 - Number(review.rating) }).map((_, index) => (
                        <Star key={`empty-${index}`} />
                    ))}
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <small>{new Date(review.createdAt).toString()}</small>
                </div>
                <p className="card-text">{review.comment}</p>
                {isAuthor && (
                    <form
                        onSubmit={(event) => {
                            event.preventDefault();
                            onDelete();
                        }}
                    >
                        <button className="btn btn-sm btn-danger">Delete</button>
                    </form>
                )}
            </div>
            </div>
        </div>
    );
}

function Star({ filled }) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" height="1rem">
            <path
                d={
                    filled
                        ? "M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z"
                        : "M287.9 0c9.2 0 17.6 5.2 21.6 13.5l68.6 141.3 153.2 22.6c9 1.3 16.5 7.6 19.3 16.3s.5 18.1-5.9 24.5L433.6 328.4l26.2 155.6c1.5 9-2.2 18.1-9.7 23.5s-17.3 6-25.3 1.7l-137-73.2L151 509.1c-8.1 4.3-17.9 3.7-25.3-1.7s-11.2-14.5-9.7-23.5l26.2-155.6L31.1 218.2c-6.5-6.4-8.7-15.9-5.9-24.5s10.3-14.9 19.3-16.3l153.2-22.6L266.3 13.5C270.4 5.2 278.7 0 287.9 0zm0 79L235.4 187.2c-3.5 7.1-10.2 12.1-18.1 13.3L99 217.9 184.9 303c5.5 5.5 8.1 13.3 6.8 21L171.4 443.7l105.2-56.2c7.1-3.8 15.6-3.8 22.6 0l105.2 56.2L384.2 324.1c-1.3-7.7 1.2-15.5 6.8-21l85.9-85.1L358.6 200.5c-7.8-1.2-14.6-6.1-18.1-13.3L287.9 79z"
                }
            />
        </svg>
    );
}
