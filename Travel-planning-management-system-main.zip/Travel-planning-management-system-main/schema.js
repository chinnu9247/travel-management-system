const Joi = require("joi");

const listingCategories = [
    "amazing-views",
    "trending",
    "bed-and-breakfasts",
    "arctic",
    "camping",
    "amazing-pools",
    "castles",
];

module.exports.listingSchema = Joi.object({
    listing: Joi.object({
        title: Joi.string().required(),
        description: Joi.string().required(),
        location: Joi.string().required(),
        country: Joi.string().required(),
        price: Joi.number().min(0).required(),
        category: Joi.string().valid(...listingCategories).default("amazing-views"),
        image: Joi.string().allow("", null),
    }).required(),
});

module.exports.listingCategories = listingCategories;

module.exports.reviewSchema = Joi.object({
    review: Joi.object({
        rating: Joi.number().min(1).max(5).required(),
        comment: Joi.string().required(),
    }).required(),
});

module.exports.bookingSchema = Joi.object({
    booking: Joi.object({
        checkIn: Joi.date().iso().greater("now").required().messages({
            "date.greater": "Check-in date must be in the future.",
        }),
        checkOut: Joi.date().iso().greater(Joi.ref("checkIn")).required().messages({
            "date.greater": "Check-out date must be after check-in date.",
        }),
        guests: Joi.number().integer().min(1).max(20).required(),
    }).required(),
});

module.exports.signupSchema = Joi.object({
    username: Joi.string().trim().min(3).max(30).required(),
    email: Joi.string().trim().email().required(),
    password: Joi.string().min(6).max(128).required(),
});

module.exports.loginSchema = Joi.object({
    username: Joi.string().trim().required(),
    password: Joi.string().required(),
});
