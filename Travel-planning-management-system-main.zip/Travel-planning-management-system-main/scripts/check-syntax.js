const { spawnSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const roots = ["app.js", "cloudConfig.js", "schema.js", "config", "controllers", "middleware", "models", "routes", "services", "utils", "init"];
const files = [];

const collect = (target) => {
    const absolute = path.join(process.cwd(), target);
    if (!fs.existsSync(absolute)) return;

    const stat = fs.statSync(absolute);
    if (stat.isFile() && absolute.endsWith(".js")) {
        files.push(absolute);
        return;
    }

    if (stat.isDirectory()) {
        for (const entry of fs.readdirSync(absolute)) {
            collect(path.join(target, entry));
        }
    }
};

roots.forEach(collect);

for (const file of files) {
    const result = spawnSync(process.execPath, ["--check", file], { stdio: "inherit" });
    if (result.status !== 0) process.exit(result.status);
}
