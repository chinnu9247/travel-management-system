const getEnv = (name) => process.env[name] || process.env[`﻿${name}`] || process.env[`ï»¿${name}`];

const isProduction = process.env.NODE_ENV === "production";
const cloudDatabaseUrl = getEnv("ATLAS_DB_URL") || getEnv("MONGODB_URI");
const hasUsableDatabaseUrl = Boolean(cloudDatabaseUrl && !cloudDatabaseUrl.includes("<db_password>"));
const sessionSecret = getEnv("SECRET") || "explore-hut-dev-secret";

const validateStartupEnv = () => {
    if (isProduction && (!hasUsableDatabaseUrl || !getEnv("SECRET"))) {
        throw new Error("Missing required production environment variables: ATLAS_DB_URL and SECRET.");
    }

    if (!hasUsableDatabaseUrl) {
        console.warn("ATLAS_DB_URL is not set or still contains <db_password>. API routes that require MongoDB will return 503 until it is configured.");
    }

    if (!getEnv("SECRET")) {
        console.warn("SECRET is not set. Using a development-only session secret.");
    }
};

module.exports = {
    cloudDatabaseUrl,
    getEnv,
    hasUsableDatabaseUrl,
    isProduction,
    sessionSecret,
    validateStartupEnv,
};
