const mongoose = require("mongoose");

const serializeUser = (user) => user && { _id: user._id.toString(), username: user.username, email: user.email };

const session = (req, res) => {
    res.json({
        currentUser: serializeUser(req.user),
        success: req.flash("success"),
        error: req.flash("error"),
    });
};

const health = (req, res) => {
    res.json({
        ok: true,
        database: mongoose.connection.readyState === 1 ? "connected" : "disconnected",
        cloudinary: process.env.CLOUD_NAME && process.env.CLOUD_API_KEY && process.env.CLOUD_API_SECRET ? "configured" : "missing",
    });
};

module.exports = {
    health,
    serializeUser,
    session,
};
