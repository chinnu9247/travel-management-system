const { isValidObjectId } = require("../middleware/auth.js");
const notificationService = require("../services/notificationService.js");

const index = async (req, res) => {
    const notifications = await notificationService.listNotificationsForUser(req.user._id);
    const unreadCount = await notificationService.countUnreadForUser(req.user._id);
    res.json({ notifications, unreadCount });
};

const unreadCount = async (req, res) => {
    const count = await notificationService.countUnreadForUser(req.user._id);
    res.json({ unreadCount: count });
};

const markRead = async (req, res) => {
    if (!isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid notification id." });

    const notification = await notificationService.markNotificationRead({
        notificationId: req.params.id,
        recipientId: req.user._id,
    });

    if (!notification) return res.status(404).json({ message: "Notification does not exist." });
    res.json({ notification });
};

const markAllRead = async (req, res) => {
    await notificationService.markAllNotificationsRead(req.user._id);
    res.json({ message: "Notifications marked as read." });
};

module.exports = {
    index,
    markAllRead,
    markRead,
    unreadCount,
};
