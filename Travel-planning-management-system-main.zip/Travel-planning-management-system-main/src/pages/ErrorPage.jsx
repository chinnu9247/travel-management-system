export default function ErrorPage({ message }) {
    return (
        <div className="row">
            <div className="alert alert-danger col-6 offset-3 mt-4" role="alert">
                <p className="alert-heading">{message}</p>
            </div>
        </div>
    );
}
