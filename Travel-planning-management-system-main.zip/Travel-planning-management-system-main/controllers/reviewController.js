const { isValidObjectId } = require("../middleware/auth.js");
const reviewService = require("../services/reviewService.js");

const create = async (req, res) => {
    if (!isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid listing id." });
    const review = await reviewService.createReview({
        listingId: req.params.id,
        reviewData: req.body.review,
        authorId: req.user._id,
    });
    req.flash("success", "New Review Added!");
    res.status(201).json({ review });
};

const destroy = async (req, res) => {
    if (!isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid listing id." });
    await reviewService.deleteReview({ listingId: req.params.id, reviewId: req.params.reviewId });
    req.flash("success", "Review Deleted!");
    res.json({ redirect: `/listings/${req.params.id}` });
};

module.exports = {
    create,
    destroy,
};
