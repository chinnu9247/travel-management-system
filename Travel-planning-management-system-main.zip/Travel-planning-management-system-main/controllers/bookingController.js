const { isValidObjectId } = require("../middleware/auth.js");
const bookingService = require("../services/bookingService.js");

const create = async (req, res) => {
    if (!isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid listing id." });

    const booking = await bookingService.createBooking({
        listingId: req.params.id,
        guestId: req.user._id,
        bookingData: { ...req.body.booking, username: req.user.username },
    });

    req.flash("success", "Booking confirmed!");
    res.status(201).json({ booking });
};

const index = async (req, res) => {
    const bookings = await bookingService.listBookingsForUser(req.user._id);
    res.json({ bookings });
};

module.exports = {
    create,
    index,
};
