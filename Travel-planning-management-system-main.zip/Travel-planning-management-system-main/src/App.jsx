import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useCallback, useEffect, useState } from "react";
import { api } from "./api";
import Layout from "./components/Layout.jsx";
import ListingsIndex from "./pages/ListingsIndex.jsx";
import ListingShow from "./pages/ListingShow.jsx";
import ListingForm from "./pages/ListingForm.jsx";
import BookingsIndex from "./pages/BookingsIndex.jsx";
import NotificationsIndex from "./pages/NotificationsIndex.jsx";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import ErrorPage from "./pages/ErrorPage.jsx";

export default function App() {
    const [currentUser, setCurrentUser] = useState(null);
    const [flash, setFlash] = useState({ success: [], error: [] });
    const [loadingSession, setLoadingSession] = useState(true);
    const [unreadNotifications, setUnreadNotifications] = useState(0);
    const location = useLocation();

    const showError = (message) => setFlash({ success: [], error: [message] });
    const clearFlash = useCallback(() => setFlash({ success: [], error: [] }), []);
    const handleLogout = () => {
        setCurrentUser(null);
        setUnreadNotifications(0);
        setFlash({ success: ["Logout successful."], error: [] });
    };

    const refreshNotifications = async () => {
        if (!currentUser) {
            setUnreadNotifications(0);
            return;
        }
        const data = await api.unreadNotifications();
        setUnreadNotifications(data.unreadCount || 0);
    };

    const refreshSession = async () => {
        const data = await api.session();
        setCurrentUser(data.currentUser);
        setFlash({ success: data.success || [], error: data.error || [] });
        setLoadingSession(false);
    };

    useEffect(() => {
        refreshSession().catch(() => setLoadingSession(false));
    }, [location.pathname]);

    useEffect(() => {
        if (!loadingSession) refreshNotifications().catch(() => setUnreadNotifications(0));
    }, [currentUser?._id, location.pathname, loadingSession]);

    if (loadingSession) return null;

    return (
        <Layout currentUser={currentUser} flash={flash} clearFlash={clearFlash} onLogout={handleLogout} unreadNotifications={unreadNotifications}>
            <Routes>
                <Route path="/" element={<Navigate to="/listings" replace />} />
                <Route path="/listings" element={<ListingsIndex showError={showError} />} />
                <Route path="/bookings" element={<BookingsIndex currentUser={currentUser} showError={showError} />} />
                <Route
                    path="/notifications"
                    element={<NotificationsIndex currentUser={currentUser} showError={showError} refreshNotifications={refreshNotifications} />}
                />
                <Route path="/listings/new" element={<ListingForm mode="new" currentUser={currentUser} showError={showError} />} />
                <Route
                    path="/listings/:id"
                    element={<ListingShow currentUser={currentUser} refreshSession={refreshSession} refreshNotifications={refreshNotifications} showError={showError} />}
                />
                <Route path="/listings/:id/edit" element={<ListingForm mode="edit" currentUser={currentUser} showError={showError} />} />
                <Route path="/login" element={<Login refreshSession={refreshSession} showError={showError} />} />
                <Route path="/signup" element={<Signup refreshSession={refreshSession} showError={showError} />} />
                <Route path="*" element={<ErrorPage message="Page Not Found!" />} />
            </Routes>
        </Layout>
    );
}
