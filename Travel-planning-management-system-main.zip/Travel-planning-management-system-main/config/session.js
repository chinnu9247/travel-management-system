const MongoStore = require("connect-mongo");
const { cloudDatabaseUrl, hasUsableDatabaseUrl, isProduction, sessionSecret } = require("./env.js");

const createSessionStore = () => {
    if (!hasUsableDatabaseUrl || !isProduction) return undefined;

    const store = MongoStore.create({
        mongoUrl: cloudDatabaseUrl,
        touchAfter: 24 * 3600,
    });

    store.on("error", (error) => {
        console.log("ERROR in MONGO SESSION STORE!");
        console.error(error);
    });

    return store;
};

const createSessionOptions = () => ({
    store: createSessionStore(),
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 7 * 24 * 60 * 60 * 1000,
        httpOnly: true,
        sameSite: "lax",
        secure: isProduction,
    },
});

module.exports = { createSessionOptions };
