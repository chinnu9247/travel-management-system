const { bookingSchema, listingSchema, loginSchema, reviewSchema, signupSchema } = require("../schema.js");
const ExpressError = require("../utils/ExpressError.js");

const normalizeListingBody = (req, res, next) => {
    if (!req.body.listing) {
        req.body.listing = {
            title: req.body["listing[title]"],
            description: req.body["listing[description]"],
            location: req.body["listing[location]"],
            country: req.body["listing[country]"],
            price: Number(req.body["listing[price]"]),
            category: req.body["listing[category]"],
        };
    }
    next();
};

const validateListing = (req, res, next) => {
    const { error, value } = listingSchema.validate(req.body);
    if (error) throw new ExpressError(400, error.message);
    req.body = value;
    next();
};

const validateReview = (req, res, next) => {
    const { error, value } = reviewSchema.validate(req.body);
    if (error) throw new ExpressError(400, error.message);
    req.body = value;
    next();
};

const validateBooking = (req, res, next) => {
    const { error, value } = bookingSchema.validate(req.body);
    if (error) throw new ExpressError(400, error.message);
    req.body = value;
    next();
};

const validateSignup = (req, res, next) => {
    const { error, value } = signupSchema.validate(req.body);
    if (error) return res.status(400).json({ message: error.message, redirect: "/signup" });
    req.body = value;
    next();
};

const validateLogin = (req, res, next) => {
    const { error, value } = loginSchema.validate(req.body);
    if (error) return res.status(400).json({ message: error.message, redirect: "/login" });
    req.body = value;
    next();
};

module.exports = {
    normalizeListingBody,
    validateBooking,
    validateListing,
    validateLogin,
    validateReview,
    validateSignup,
};
