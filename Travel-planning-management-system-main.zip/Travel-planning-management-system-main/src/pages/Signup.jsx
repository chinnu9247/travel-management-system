import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { api } from "../api";
import useValidation from "../hooks/useValidation";

export default function Signup({ refreshSession, showError }) {
    const navigate = useNavigate();
    const validate = useValidation();
    const [showPassword, setShowPassword] = useState(false);

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (!validate(event)) return;

        const formData = new FormData(event.currentTarget);
        try {
            const data = await api.signup({
                username: formData.get("username"),
                email: formData.get("email"),
                password: formData.get("password"),
            });
            await refreshSession();
            navigate(data.redirect || "/listings");
        } catch (error) {
            showError(error.message);
        }
    };

    return (
        <div className="row justify-content-center">
            <div className="col-12 col-sm-10 col-md-8 col-lg-6">
                <div className="border border-secondary border-1 rounded-3 my-4 px-3 px-md-5 py-4 auth-panel">
                    <h1 className="mb-2 fw-bold text-center">Sign Up</h1>
                    <small className="d-block mb-3 text-center">Create your account here</small>

                    <form onSubmit={handleSubmit} className="needs-validation" noValidate>
                        <div className="mb-4">
                            <label htmlFor="username" className="form-label fw-bold">
                                Username
                            </label>
                            <input type="text" name="username" id="username" className="form-control border border-1 border-secondary-subtle p-2" required />
                        </div>

                        <div className="mb-4">
                            <label htmlFor="email" className="form-label fw-bold">
                                Email
                            </label>
                            <input type="text" name="email" id="email" className="form-control border border-1 border-secondary-subtle p-2" required />
                        </div>

                        <div className="mb-4">
                            <label htmlFor="password" className="form-label fw-bold">
                                Password
                            </label>
                            <div className="password-field">
                                <input
                                    type={showPassword ? "text" : "password"}
                                    name="password"
                                    id="password"
                                    className="form-control border border-1 border-secondary-subtle p-2 pe-5"
                                    required
                                />
                                <button
                                    type="button"
                                    className="password-toggle"
                                    onClick={() => setShowPassword((isVisible) => !isVisible)}
                                    aria-label={showPassword ? "Hide password" : "Show password"}
                                    title={showPassword ? "Hide password" : "Show password"}
                                >
                                    <i className={showPassword ? "fa-regular fa-eye-slash" : "fa-regular fa-eye"}></i>
                                </button>
                            </div>
                        </div>

                        <button className="btn btn-success w-100 fw-bold border-0 mb-4 p-2">SignUp</button>

                        <small className="d-block text-center">
                            Already have an account? <Link to="/login">Login</Link>
                        </small>
                    </form>
                </div>
            </div>
        </div>
    );
}
