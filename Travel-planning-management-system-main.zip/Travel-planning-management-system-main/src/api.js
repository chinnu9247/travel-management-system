const request = async (url, options = {}) => {
    const response = await fetch(url, {
        credentials: "include",
        headers: options.body instanceof FormData ? undefined : { "Content-Type": "application/json" },
        ...options,
    }).catch(() => {
        throw new ApiError("Server is unavailable. Please check that the backend is running.");
    });
    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
        throw new ApiError(data.message || "Something Went Wrong!", response.status, data.redirect);
    }

    return data;
};

export class ApiError extends Error {
    constructor(message, status, redirect) {
        super(message);
        this.name = "ApiError";
        this.status = status;
        this.redirect = redirect;
    }
}

export const api = {
    session: () => request("/api/session"),
    listings: ({ category, search } = {}) => {
        const params = new URLSearchParams();
        if (category && category !== "all") params.set("category", category);
        if (search) params.set("search", search);
        const query = params.toString();
        return request(query ? `/api/listings?${query}` : "/api/listings");
    },
    listing: (id) => request(`/api/listings/${id}`),
    createListing: (formData) => request("/api/listings", { method: "POST", body: formData }),
    updateListing: (id, formData) => request(`/api/listings/${id}`, { method: "PUT", body: formData }),
    deleteListing: (id) => request(`/api/listings/${id}`, { method: "DELETE" }),
    bookings: () => request("/api/bookings"),
    createBooking: (id, body) => request(`/api/listings/${id}/bookings`, { method: "POST", body: JSON.stringify(body) }),
    notifications: () => request("/api/notifications"),
    unreadNotifications: () => request("/api/notifications/unread-count"),
    markNotificationRead: (id) => request(`/api/notifications/${id}/read`, { method: "PATCH" }),
    markAllNotificationsRead: () => request("/api/notifications/read-all", { method: "PATCH" }),
    createReview: (id, body) => request(`/api/listings/${id}/reviews`, { method: "POST", body: JSON.stringify(body) }),
    deleteReview: (id, reviewId) => request(`/api/listings/${id}/reviews/${reviewId}`, { method: "DELETE" }),
    login: (body) => request("/api/login", { method: "POST", body: JSON.stringify(body) }),
    signup: (body) => request("/api/signup", { method: "POST", body: JSON.stringify(body) }),
    logout: () => request("/api/logout", { method: "POST" }),
};
