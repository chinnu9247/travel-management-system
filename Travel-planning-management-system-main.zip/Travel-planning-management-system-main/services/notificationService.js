const Notification = require("../models/notification.js");

const createNotification = (notificationData) => Notification.create(notificationData);

const createBookingNotifications = async ({ booking, listing, guest }) => {
    const stayDates = `${new Date(booking.checkIn).toLocaleDateString("en-IN")} to ${new Date(booking.checkOut).toLocaleDateString("en-IN")}`;

    await Notification.create([
        {
            recipient: guest._id,
            actor: listing.owner,
            listing: listing._id,
            booking: booking._id,
            type: "booking-confirmed",
            message: `Your booking for ${listing.title} is confirmed for ${stayDates}.`,
            link: "/bookings",
        },
        {
            recipient: listing.owner,
            actor: guest._id,
            listing: listing._id,
            booking: booking._id,
            type: "new-booking",
            message: `${guest.username} booked ${listing.title} for ${stayDates}.`,
            link: `/listings/${listing._id}`,
        },
    ]);
};

const listNotificationsForUser = async (recipientId) => Notification.find({ recipient: recipientId })
    .sort({ createdAt: -1 })
    .limit(50)
    .populate("actor", "username email")
    .populate("listing", "title location country");

const countUnreadForUser = (recipientId) => Notification.countDocuments({ recipient: recipientId, readAt: null });

const markNotificationRead = async ({ notificationId, recipientId }) => Notification.findOneAndUpdate(
    { _id: notificationId, recipient: recipientId },
    { readAt: new Date() },
    { new: true },
);

const markAllNotificationsRead = (recipientId) => Notification.updateMany(
    { recipient: recipientId, readAt: null },
    { readAt: new Date() },
);

const deleteNotificationsForListing = (listingId) => Notification.deleteMany({ listing: listingId });

module.exports = {
    countUnreadForUser,
    createBookingNotifications,
    createNotification,
    deleteNotificationsForListing,
    listNotificationsForUser,
    markAllNotificationsRead,
    markNotificationRead,
};
