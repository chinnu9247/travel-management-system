const mongoose = require("mongoose");
const passport = require("passport");
const User = require("../models/user.js");
const { serializeUser } = require("./systemController.js");

const signup = async (req, res, next) => {
    try {
        const { username, email, password } = req.body;
        const registeredUser = await User.register(new User({ email, username }), password);
        req.login(registeredUser, (error) => {
            if (error) return next(error);
            req.flash("success", "Welcome to Explore Hut!");
            res.status(201).json({ currentUser: serializeUser(registeredUser), redirect: "/listings" });
        });
    } catch (error) {
        res.status(400).json({ message: error.message, redirect: "/signup" });
    }
};

const login = (req, res, next) => {
    if (mongoose.connection.readyState !== 1) {
        return res.status(503).json({ message: "Database is not connected. Check ATLAS_DB_URL and restart the server." });
    }

    passport.authenticate("local", (error, user, info) => {
        if (error) return next(error);
        if (!user) return res.status(401).json({ message: info?.message || "Invalid username or password", redirect: "/login" });

        req.login(user, (loginError) => {
            if (loginError) return next(loginError);
            req.flash("success", "Login successful!");
            const redirect = req.session.redirectUrl || "/listings";
            delete req.session.redirectUrl;
            res.json({ currentUser: serializeUser(user), redirect });
        });
    })(req, res, next);
};

const logoutJson = (req, res, next) => {
    req.logout((error) => {
        if (error) return next(error);
        req.session?.destroy(() => {
            res.clearCookie("connect.sid");
            res.json({ redirect: "/listings" });
        });
    });
};

const logoutRedirect = (req, res, next) => {
    req.logout((error) => {
        if (error) return next(error);
        req.session?.destroy(() => {
            res.clearCookie("connect.sid");
            res.redirect("/listings");
        });
    });
};

module.exports = {
    login,
    logoutJson,
    logoutRedirect,
    signup,
};
