const express = require("express");
const wrapAsync = require("../utils/wrapAsync.js");
const upload = require("../middleware/upload.js");
const { isLoggedIn, isOwner, isReviewAuthor } = require("../middleware/auth.js");
const { requireCloudinary, requireDb } = require("../middleware/system.js");
const { normalizeListingBody, validateBooking, validateListing, validateLogin, validateReview, validateSignup } = require("../middleware/validation.js");
const authController = require("../controllers/authController.js");
const bookingController = require("../controllers/bookingController.js");
const listingController = require("../controllers/listingController.js");
const notificationController = require("../controllers/notificationController.js");
const reviewController = require("../controllers/reviewController.js");
const systemController = require("../controllers/systemController.js");

const router = express.Router();

router.get("/session", systemController.session);
router.get("/health", systemController.health);

router.get("/bookings", requireDb, isLoggedIn, wrapAsync(bookingController.index));
router.get("/notifications", requireDb, isLoggedIn, wrapAsync(notificationController.index));
router.get("/notifications/unread-count", requireDb, isLoggedIn, wrapAsync(notificationController.unreadCount));
router.patch("/notifications/read-all", requireDb, isLoggedIn, wrapAsync(notificationController.markAllRead));
router.patch("/notifications/:id/read", requireDb, isLoggedIn, wrapAsync(notificationController.markRead));

router
    .route("/listings")
    .get(requireDb, wrapAsync(listingController.index))
    .post(
        requireDb,
        isLoggedIn,
        requireCloudinary,
        upload.single("listing[image]"),
        normalizeListingBody,
        validateListing,
        wrapAsync(listingController.create),
    );

router
    .route("/listings/:id")
    .get(requireDb, wrapAsync(listingController.show))
    .put(
        requireDb,
        isLoggedIn,
        wrapAsync(isOwner),
        upload.single("listing[image]"),
        normalizeListingBody,
        validateListing,
        wrapAsync(listingController.update),
    )
    .delete(requireDb, isLoggedIn, wrapAsync(isOwner), wrapAsync(listingController.destroy));

router.post(
    "/listings/:id/reviews",
    requireDb,
    isLoggedIn,
    validateReview,
    wrapAsync(reviewController.create),
);

router.post(
    "/listings/:id/bookings",
    requireDb,
    isLoggedIn,
    validateBooking,
    wrapAsync(bookingController.create),
);

router.delete(
    "/listings/:id/reviews/:reviewId",
    requireDb,
    isLoggedIn,
    wrapAsync(isReviewAuthor),
    wrapAsync(reviewController.destroy),
);

router.post("/signup", validateSignup, requireDb, wrapAsync(authController.signup));
router.post("/login", validateLogin, authController.login);
router.post("/logout", authController.logoutJson);

module.exports = router;
