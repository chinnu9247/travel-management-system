import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";

export default function Navbar({ currentUser, onLogout, unreadNotifications = 0 }) {
    const navigate = useNavigate();

    const handleLogout = async (event) => {
        event.preventDefault();
        try {
            await api.logout();
            onLogout();
            navigate("/listings");
        } catch {
            navigate("/listings");
        }
    };

    const handleSearch = (event) => {
        event.preventDefault();
        const formData = new FormData(event.currentTarget);
        const search = String(formData.get("search") || "").trim();
        navigate(search ? `/listings?search=${encodeURIComponent(search)}` : "/listings");
    };

    return (
        <nav className="navbar navbar-expand-md bg-light border-bottom sticky-top">
            <div className="container-fluid">
                <Link className="navbar-brand mx-4" to="/listings">
                    <i className="fa-regular fa-compass"></i>
                </Link>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div className="navbar-nav fw-bold">
                        <Link className="nav-link" to="/listings">
                            Explore
                        </Link>
                    </div>
                    <div className="navbar-nav m-auto">
                        <form className="d-flex" role="search" onSubmit={handleSearch}>
                            <input className="form-control me-2 search-box" type="search" name="search" placeholder="Search destinations" aria-label="Search" />
                            <button className="search-btn" type="submit">
                                <i className="fa-solid fa-magnifying-glass"></i>&nbsp;&nbsp;<strong>Search</strong>
                            </button>
                        </form>
                    </div>

                    <div className="navbar-nav fw-bold ms-auto">
                        <Link className="nav-link" to="/listings/new">
                            Add Your Hut
                        </Link>
                        {!currentUser ? (
                            <>
                                <Link className="nav-link" to="/login">
                                    Log In
                                </Link>
                                <Link className="nav-link" to="/signup">
                                    Sign Up
                                </Link>
                            </>
                        ) : (
                            <>
                                <Link className="nav-link" to="/bookings">
                                    My Bookings
                                </Link>
                                <Link className="nav-link notification-nav-link" to="/notifications">
                                    Notifications
                                    {unreadNotifications > 0 && (
                                        <span className="notification-badge">{unreadNotifications > 9 ? "9+" : unreadNotifications}</span>
                                    )}
                                </Link>
                                <a className="nav-link" href="/logout" onClick={handleLogout}>
                                    Log Out
                                </a>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </nav>
    );
}
