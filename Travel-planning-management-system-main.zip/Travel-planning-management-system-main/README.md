# Explore Hut

Explore Hut is a responsive travel listing management app. It uses an Express and MongoDB backend with a React + Vite frontend for browsing stays, creating listings, uploading images, and adding reviews.
https://travel-planning-management-system.onrender.com/listings

## Features

* Responsive listings grid for mobile, tablet, and desktop
* Category filters and tax toggle
* Search listings by destination or title
* User signup, login, logout, and session handling
* Create, edit, and delete listings
* Cloudinary image uploads
* Reviews and ratings
* MongoDB-backed seed data from `init/data.js`
* Production build served by Express from `dist/`

## Tech Stack

* Node.js + Express
* MongoDB + Mongoose
* Passport session authentication
* Cloudinary
* React + Vite
* React Router
* Bootstrap
* Font Awesome
* Google Fonts

## Environment Variables

Create a `.env` file using `.env.example` as a guide:

```env
ATLAS_DB_URL=your MongoDB Atlas connection string
SECRET=your long random session secret
CLOUD_NAME=your Cloudinary cloud name
CLOUD_API_KEY=your Cloudinary API key
CLOUD_API_SECRET=your Cloudinary API secret
PORT=8080
```

For production on Render, also set:

```env
NODE_ENV=production
```

Do not set `PORT` on Render. Render provides it automatically.

## Run Locally

Install dependencies:

```bash
npm install --legacy-peer-deps
```

Start the development server:

```bash
npm run dev
```

Build the frontend:

```bash
npm run build
```

Run the production Express server locally:

```bash
npm start
```

Then open:

```text
http://127.0.0.1:8080/listings
```

## Seed Database

Fill MongoDB with sample listings from `init/data.js`:

```bash
npm run seed
```

The seed script uses `ATLAS_DB_URL` or `MONGODB_URI` from `.env`. If neither is set, it falls back to local MongoDB at `mongodb://127.0.0.1:27017/Explore-Hut`.

## Useful Commands

```bash
npm run check
npm run build
npm start
npm run seed
```

## Render Deployment

Use these Render settings:

```text
Language: Node
Root Directory: leave blank
Build Command: npm install --legacy-peer-deps --include=dev && npm run build
Start Command: npm start
```

Required Render environment variables:

```env
NODE_ENV=production
ATLAS_DB_URL=your MongoDB Atlas connection string
SECRET=your long random session secret
CLOUD_NAME=your Cloudinary cloud name
CLOUD_API_KEY=your Cloudinary API key
CLOUD_API_SECRET=your Cloudinary API secret
```

The project also includes `render.yaml` with the same deployment configuration.

## Project Structure

```text
app.js           Express app entry point
config/          Environment, database, and session config
controllers/     Request handlers
models/          MongoDB models
routes/          API routes
services/        Business logic
middleware/      Auth, validation, upload, and system middleware
src/             React app
public/CSS/      App styling
dist/            Vite production build
init/            Database seed data and seed script
scripts/         Utility scripts
utils/           Shared Express helpers
```

## React Pages

* Listings index: `src/pages/ListingsIndex.jsx`
* Listing details and reviews: `src/pages/ListingShow.jsx`
* New/edit listing form: `src/pages/ListingForm.jsx`
* Login: `src/pages/Login.jsx`
* Signup: `src/pages/Signup.jsx`
* Shared layout and navbar: `src/components/`
