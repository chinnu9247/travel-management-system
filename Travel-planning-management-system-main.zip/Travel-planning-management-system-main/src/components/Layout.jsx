import { Link } from "react-router-dom";
import { useEffect } from "react";
import Navbar from "./Navbar.jsx";

export default function Layout({ children, currentUser, flash, clearFlash, onLogout, unreadNotifications }) {
    return (
        <>
            <Navbar currentUser={currentUser} onLogout={onLogout} unreadNotifications={unreadNotifications} />
            <div className="container">
                <FlashMessages flash={flash} clearFlash={clearFlash} />
                {children}
            </div>
        </>
    );
}

function FlashMessages({ flash, clearFlash }) {
    const success = Array.isArray(flash.success) ? flash.success : [flash.success].filter(Boolean);
    const error = Array.isArray(flash.error) ? flash.error : [flash.error].filter(Boolean);

    useEffect(() => {
        if (!success.length && !error.length) return undefined;
        const timeoutId = window.setTimeout(clearFlash, 3500);
        return () => window.clearTimeout(timeoutId);
    }, [success.join("|"), error.join("|"), clearFlash]);

    return (
        <>
            {!!success.length && (
                <div className="alert alert-success alert-dismissible fade show app-alert mt-2 mb-0" role="alert">
                    <strong>{success.join(", ")}</strong>
                    <button type="button" className="btn-close" aria-label="Close" onClick={clearFlash}></button>
                </div>
            )}
            {!!error.length && (
                <div className="alert alert-danger alert-dismissible fade show app-alert mt-2 mb-0" role="alert">
                    <strong>{error.join(", ")}</strong>
                    <button type="button" className="btn-close" aria-label="Close" onClick={clearFlash}></button>
                </div>
            )}
        </>
    );
}

export function BackButton({ to }) {
    return (
        <Link to={to}>
            <button className="btn btn-secondary mt-2">Back</button>
        </Link>
    );
}
