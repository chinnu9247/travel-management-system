/**
 * We have created this `/init` folder to initialise database with fresh data.
 * so, we can perform project setup and data initialisation in this file.
 */

const mongoose = require("mongoose");
require("dotenv").config();
const initData = require("./data.js"); // Importing data from data.js file.
const Listing = require("../models/listing.js"); // Importing Listing model from models folder.
const User = require("../models/user.js");

const MONGO_URL = process.env.ATLAS_DB_URL || process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/Explore-Hut";

/* Database connectivity setup */
main()
    .then(() => {
        console.log("Database connected.");
    })
    .catch((err) => console.log(err));

async function main() {
    await mongoose.connect(MONGO_URL);
}

const initDB = async () => {
    const owner = await User.findOne({ username: "demo-owner" }) || await User.register(
        new User({ username: "demo-owner", email: "demo-owner@example.com" }),
        "demo-password",
    );
    await Listing.deleteMany({});
    const listings = initData.data.map((listing) => ({ ...listing, owner: owner._id }));
    await Listing.insertMany(listings);
    console.log("Data is initialized.");
};

initDB()
    .catch((err) => {
        console.error(err);
        process.exitCode = 1;
    })
    .finally(async () => {
        await mongoose.connection.close();
    });
