const mongoose = require("mongoose"); // Importing/Requiring mongoose from package.
const Schema = mongoose.Schema; // Importing mongoose module and Schema.
const Review = require("./review.js");
const Booking = require("./booking.js");
const Notification = require("./notification.js");

/* Schema defining */
const listingSchema = new Schema({
    title: {
        type: String,
        required: true,
        trim: true,
    },
    description: { type: String, trim: true },
    image: {
        url: String,
        filename: String,
    },
    price: { type: Number, min: 0 },
    location: { type: String, trim: true, index: true },
    country: { type: String, trim: true, index: true },
    category: { type: String, trim: true, lowercase: true, default: "amazing-views", index: true },
    reviews: [{ type: Schema.Types.ObjectId, ref: "Review" }],
    owner: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
});

// Post Mongoose Middleware
listingSchema.post("findOneAndDelete", async (listing) => {
    if (listing) {
        await Review.deleteMany({ _id: { $in: listing.reviews } });
        await Booking.deleteMany({ listing: listing._id });
        await Notification.deleteMany({ listing: listing._id });
    }
});

/* Model creating and exporting */
const Listing = mongoose.model("Listing", listingSchema); // Creating a model from the schema.
module.exports = Listing; // Exporting the model for use in other parts of the application.
