const mongoose = require("mongoose");
const ExpressError = require("../utils/ExpressError.js");

const requireDb = (req, res, next) => {
    if (mongoose.connection.readyState !== 1) {
        return res.status(503).json({ message: "Database is not connected. Check ATLAS_DB_URL and restart the server." });
    }
    next();
};

const requireCloudinary = (req, res, next) => {
    const hasCloudinaryConfig = process.env.CLOUD_NAME && process.env.CLOUD_API_KEY && process.env.CLOUD_API_SECRET;
    if (!hasCloudinaryConfig) {
        return res.status(503).json({ message: "Cloudinary environment variables are missing. File uploads are unavailable." });
    }
    next();
};

const attachFlashLocals = (req, res, next) => {
    res.locals.success = req.flash("success");
    res.locals.error = req.flash("error");
    res.locals.currentUser = req.user;
    next();
};

const spaFallback = (rootDir) => (req, res, next) => {
    if (req.path.startsWith("/api")) return next(new ExpressError(404, "Page Not Found!"));

    const fs = require("fs");
    const path = require("path");
    const builtIndex = path.join(rootDir, "dist", "index.html");
    const devIndex = path.join(rootDir, "index.html");
    res.sendFile(fs.existsSync(builtIndex) ? builtIndex : devIndex);
};

const errorHandler = (err, req, res, next) => {
    if (res.headersSent) return next(err);
    const { statusCode = 500, message = "Something Went Wrong!" } = err;
    res.status(statusCode).json({ message });
};

module.exports = {
    attachFlashLocals,
    errorHandler,
    requireCloudinary,
    requireDb,
    spaFallback,
};
