import { Link, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { api } from "../api";

const fallbackImage = "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=800&q=60";

const filters = [
    ["all", "fa-solid fa-globe", "All"],
    ["amazing-views", "fa-solid fa-mountain-sun", "Amazing Views"],
    ["trending", "fa-solid fa-fire", "Trending"],
    ["bed-and-breakfasts", "fa-solid fa-mug-hot", "Bed & Breakfasts"],
    ["arctic", "fa-regular fa-snowflake", "Arctic"],
    ["camping", "fa-solid fa-campground", "Camping"],
    ["amazing-pools", "fa-solid fa-person-swimming", "Amazing Pools"],
    ["castles", "fa-brands fa-fort-awesome", "Castles"],
];

export default function ListingsIndex({ showError }) {
    const location = useLocation();
    const searchTerm = new URLSearchParams(location.search).get("search")?.trim() || "";
    const [listings, setListings] = useState([]);
    const [activeCategory, setActiveCategory] = useState("all");
    const [loading, setLoading] = useState(true);
    const [showTax, setShowTax] = useState(false);

    useEffect(() => {
        setLoading(true);
        api.listings({ category: activeCategory, search: searchTerm })
            .then((data) => setListings(data.listings))
            .catch((error) => showError(error.message))
            .finally(() => setLoading(false));
    }, [activeCategory, searchTerm]);

    return (
        <>
            <div id="filter-tax-switch-container">
                <div className="filters-container">
                    {filters.map(([key, icon, label]) => (
                        <button
                            type="button"
                            className="filter border-0 bg-transparent p-0"
                            key={key}
                            onClick={() => setActiveCategory(key)}
                            style={{ opacity: activeCategory === key ? 1 : undefined }}
                            aria-pressed={activeCategory === key}
                        >
                            <i className={icon}></i>
                            <small>{label}</small>
                        </button>
                    ))}
                </div>

                <div className="tax-toggle-container">
                    <div className="form-check-reverse form-switch">
                        <input
                            className="form-check-input"
                            type="checkbox"
                            role="switch"
                            id="flexSwitchCheckDefault"
                            checked={showTax}
                            onChange={(event) => setShowTax(event.target.checked)}
                        />
                        <label className="form-check-label" htmlFor="flexSwitchCheckDefault">
                            Display total before taxes
                        </label>
                    </div>
                </div>
            </div>

            {!loading && searchTerm && (
                <div className="search-results-title text-secondary">
                    Search results for <strong>{searchTerm}</strong>
                </div>
            )}

            <div className="card-container row row-cols-1 row-cols-sm-2 row-cols-xl-3 g-4">
                {loading && (
                    <div className="col-12 text-center text-secondary my-5">
                        <i className="fa-solid fa-spinner fa-spin me-2"></i>
                        Loading listings...
                    </div>
                )}
                {!loading && listings.length === 0 && (
                    <div className="col-12 text-center text-secondary my-5">
                        <i className="fa-solid fa-house-crack d-block fs-1 mb-3"></i>
                        No listings found.
                    </div>
                )}
                {!loading && listings.map((listing) => (
                    <div className="col" key={listing._id}>
                        <Link to={`/listings/${listing._id}`} className="listing-link">
                        <div className="card listing-card h-100">
                            <img src={listing.image?.url || fallbackImage} className="card-img-top listing-img" alt={listing.title || "Listing image"} />
                            <div className="card-img-overlay"></div>
                            <div className="card-body">
                                <h6 className="card-title">{listing.title}</h6>
                                <p className="card-text">
                                    &#8377;{Number(listing.price).toLocaleString("en-IN")}
                                    <span> per guest</span>
                                    <small>
                                        <i className="tax-info" style={{ display: showTax ? "inline" : "none" }}>
                                            &nbsp;&nbsp;&nbsp;&nbsp;+18% GST
                                        </i>
                                    </small>
                                </p>
                            </div>
                        </div>
                        </Link>
                    </div>
                ))}
            </div>
        </>
    );
}
