const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const bookingSchema = new Schema(
    {
        listing: { type: Schema.Types.ObjectId, ref: "Listing", required: true, index: true },
        guest: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
        checkIn: { type: Date, required: true },
        checkOut: { type: Date, required: true },
        guests: { type: Number, required: true, min: 1, max: 20 },
        totalPrice: { type: Number, required: true, min: 0 },
        status: {
            type: String,
            enum: ["confirmed", "cancelled"],
            default: "confirmed",
            index: true,
        },
    },
    { timestamps: true },
);

module.exports = mongoose.model("Booking", bookingSchema);
