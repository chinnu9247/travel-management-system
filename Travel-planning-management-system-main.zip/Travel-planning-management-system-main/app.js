// Check for NODE_ENV is not set on "production".
if (process.env.NODE_ENV != "production") require("dotenv").config();

const express = require("express");
const path = require("path");
const session = require("express-session");
const flash = require("connect-flash");
const passport = require("passport");
const LocalStrategy = require("passport-local");
const User = require("./models/user.js");

const { connectDatabase } = require("./config/database.js");
const { isProduction, validateStartupEnv } = require("./config/env.js");
const { createSessionOptions } = require("./config/session.js");
const { attachFlashLocals, errorHandler, spaFallback } = require("./middleware/system.js");
const authController = require("./controllers/authController.js");
const apiRouter = require("./routes/api.js");

const app = express();
validateStartupEnv();

if (isProduction) {
    app.set("trust proxy", 1);
}

app.use(express.urlencoded({ extended: true, limit: "1mb" }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "/public")));
app.use(express.static(path.join(__dirname, "/dist")));

app.use(session(createSessionOptions()));
app.use(flash());

app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(attachFlashLocals);

app.use("/api", apiRouter);
app.get("/logout", authController.logoutRedirect);

app.all("*", spaFallback(__dirname));
app.use(errorHandler);

if (require.main === module) {
    const port = process.env.PORT || 8080;
    connectDatabase()
        .catch((err) => {
            console.error(err);
            if (isProduction) process.exit(1);
        })
        .finally(() => {
            app.listen(port, () => {
                console.log(`Server is running on localhost: ${port}`);
            });
        });
}

module.exports = app;
