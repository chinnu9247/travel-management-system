const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const notificationSchema = new Schema(
    {
        recipient: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
        actor: { type: Schema.Types.ObjectId, ref: "User", index: true },
        listing: { type: Schema.Types.ObjectId, ref: "Listing", index: true },
        booking: { type: Schema.Types.ObjectId, ref: "Booking", index: true },
        type: {
            type: String,
            enum: ["booking-confirmed", "new-booking"],
            required: true,
        },
        message: { type: String, required: true, trim: true },
        link: { type: String, default: "/notifications" },
        readAt: { type: Date, default: null, index: true },
    },
    { timestamps: true },
);

module.exports = mongoose.model("Notification", notificationSchema);
