const mongoose = require("mongoose");
const Listing = require("../models/listing.js");
const Review = require("../models/review.js");

const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

const redirectPathFromReferer = (req) => {
    const referer = req.get("referer");
    if (!referer) return "/listings";

    try {
        const url = new URL(referer);
        return `${url.pathname}${url.search}`;
    } catch {
        return referer.startsWith("/") ? referer : "/listings";
    }
};

const isLoggedIn = (req, res, next) => {
    if (!req.isAuthenticated()) {
        req.session.redirectUrl = redirectPathFromReferer(req);
        return res.status(401).json({ message: "Signup or login to create a new post!", redirect: "/login" });
    }
    next();
};

const isOwner = async (req, res, next) => {
    if (!isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid listing id." });
    const listing = await Listing.findById(req.params.id);
    if (!listing) return res.status(404).json({ message: "Requested list does not exist!" });
    if (!listing.owner.equals(req.user._id)) {
        return res.status(403).json({ message: "You are not authorized to make changes." });
    }
    next();
};

const isReviewAuthor = async (req, res, next) => {
    if (!isValidObjectId(req.params.reviewId)) return res.status(400).json({ message: "Invalid review id." });
    const review = await Review.findById(req.params.reviewId);
    if (!review) return res.status(404).json({ message: "Requested review does not exist!" });
    if (!review.author.equals(req.user._id)) {
        return res.status(403).json({ message: "You are not authorized to make changes." });
    }
    next();
};

module.exports = {
    isLoggedIn,
    isOwner,
    isReviewAuthor,
    isValidObjectId,
};
