const mongoose = require("mongoose");
const { cloudDatabaseUrl, hasUsableDatabaseUrl } = require("./env.js");

const connectDatabase = async () => {
    if (!hasUsableDatabaseUrl) return;
    await mongoose.connect(cloudDatabaseUrl, { serverSelectionTimeoutMS: 10000 });
    console.log("Database connected.");
};

module.exports = { connectDatabase };
