const Booking = require("../models/booking.js");
const Listing = require("../models/listing.js");
const notificationService = require("./notificationService.js");

const MS_PER_DAY = 24 * 60 * 60 * 1000;

const calculateNights = (checkIn, checkOut) => {
    const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / MS_PER_DAY);
    if (nights < 1) {
        const error = new Error("Check-out date must be after check-in date.");
        error.statusCode = 400;
        throw error;
    }
    return nights;
};

const createBooking = async ({ listingId, guestId, bookingData }) => {
    const listing = await Listing.findById(listingId).populate("owner", "username email");
    if (!listing) {
        const error = new Error("Requested list does not exist!");
        error.statusCode = 404;
        throw error;
    }

    if (listing.owner.equals(guestId)) {
        const error = new Error("You cannot book your own listing.");
        error.statusCode = 403;
        throw error;
    }

    const nights = calculateNights(bookingData.checkIn, bookingData.checkOut);
    const totalPrice = nights * Number(listing.price || 0) * Number(bookingData.guests || 1);

    const booking = new Booking({
        listing: listingId,
        guest: guestId,
        checkIn: bookingData.checkIn,
        checkOut: bookingData.checkOut,
        guests: bookingData.guests,
        totalPrice,
    });

    await booking.save();
    await notificationService.createBookingNotifications({ booking, listing, guest: { _id: guestId, username: bookingData.username || "A guest" } });

    return booking.populate([
        { path: "listing", select: "title location country image price" },
        { path: "guest", select: "username email" },
    ]);
};

const listBookingsForUser = async (guestId) => Booking.find({ guest: guestId })
    .sort({ createdAt: -1 })
    .populate("listing", "title location country image price")
    .populate("guest", "username email");

module.exports = {
    createBooking,
    listBookingsForUser,
};
