const { isValidObjectId } = require("../middleware/auth.js");
const listingService = require("../services/listingService.js");

const index = async (req, res) => {
    const listings = await listingService.listListings(req.query);
    res.json({ listings });
};

const create = async (req, res) => {
    const listing = await listingService.createListing({
        listingData: req.body.listing,
        file: req.file,
        ownerId: req.user._id,
    });
    req.flash("success", "New Listing Added!");
    res.status(201).json({ listing, redirect: "/listings" });
};

const show = async (req, res) => {
    if (!isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid listing id." });
    const listing = await listingService.getListingById(req.params.id);
    if (!listing) return res.status(404).json({ message: "Requested list does not exist!" });
    res.json({ listing });
};

const update = async (req, res) => {
    const listing = await listingService.updateListing({
        id: req.params.id,
        listingData: req.body.listing,
        file: req.file,
    });
    req.flash("success", "Listing Updated!");
    res.json({ listing, redirect: `/listings/${req.params.id}` });
};

const destroy = async (req, res) => {
    await listingService.deleteListing(req.params.id);
    req.flash("success", "Listing Deleted!");
    res.json({ redirect: "/listings" });
};

module.exports = {
    create,
    destroy,
    index,
    show,
    update,
};
