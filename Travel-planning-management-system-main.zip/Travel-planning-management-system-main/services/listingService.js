const Listing = require("../models/listing.js");
const { listingCategories } = require("../schema.js");
const { destroyAsset } = require("./cloudinaryService.js");

const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const buildListingFilter = ({ category, search } = {}) => {
    const filter = category && category !== "all" ? { category } : {};

    if (filter.category && !listingCategories.includes(filter.category)) {
        const error = new Error("Invalid listing category.");
        error.statusCode = 400;
        throw error;
    }

    if (filter.category === "amazing-views") {
        filter.$or = [{ category: "amazing-views" }, { category: { $exists: false } }, { category: "" }, { category: null }];
        delete filter.category;
    }

    if (typeof search === "string" && search.trim()) {
        const pattern = escapeRegex(search.trim());
        const searchFilter = {
            $or: [
                { title: { $regex: pattern, $options: "i" } },
                { location: { $regex: pattern, $options: "i" } },
                { country: { $regex: pattern, $options: "i" } },
                { description: { $regex: pattern, $options: "i" } },
            ],
        };

        if (filter.$or) {
            filter.$and = [{ $or: filter.$or }, searchFilter];
            delete filter.$or;
        } else {
            Object.assign(filter, searchFilter);
        }
    }

    return filter;
};

const listListings = async (query) => Listing.find(buildListingFilter(query)).sort({ _id: -1 });

const createListing = async ({ listingData, file, ownerId }) => {
    const listing = new Listing(listingData);
    if (file) {
        listing.image = { url: file.path, filename: file.filename };
    }
    listing.owner = ownerId;
    await listing.save();
    return listing;
};

const getListingById = async (id) => Listing.findById(id)
    .populate({ path: "reviews", populate: { path: "author" } })
    .populate("owner");

const updateListing = async ({ id, listingData, file }) => {
    const listing = await Listing.findByIdAndUpdate(id, { ...listingData }, { new: true, runValidators: true });
    if (file) {
        await destroyAsset(listing.image?.filename);
        listing.image = { url: file.path, filename: file.filename };
        await listing.save();
    }
    return listing;
};

const deleteListing = async (id) => {
    const listing = await Listing.findByIdAndDelete(id);
    await destroyAsset(listing?.image?.filename);
    return listing;
};

module.exports = {
    buildListingFilter,
    createListing,
    deleteListing,
    getListingById,
    listListings,
    updateListing,
};
