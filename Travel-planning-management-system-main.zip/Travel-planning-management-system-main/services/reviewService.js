const Listing = require("../models/listing.js");
const Review = require("../models/review.js");

const createReview = async ({ listingId, reviewData, authorId }) => {
    const listing = await Listing.findById(listingId);
    if (!listing) {
        const error = new Error("Requested list does not exist!");
        error.statusCode = 404;
        throw error;
    }

    const review = new Review(reviewData);
    review.author = authorId;
    listing.reviews.push(review);

    await review.save();
    await listing.save();

    return review;
};

const deleteReview = async ({ listingId, reviewId }) => {
    await Listing.findByIdAndUpdate(listingId, { $pull: { reviews: reviewId } });
    await Review.findByIdAndDelete(reviewId);
};

module.exports = {
    createReview,
    deleteReview,
};
