import { Link, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { api } from "../api";
import { BackButton } from "../components/Layout.jsx";

const fallbackImage = "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=800&q=60";

export default function BookingsIndex({ currentUser, showError }) {
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!currentUser) return;
        api.bookings()
            .then((data) => setBookings(data.bookings || []))
            .catch((error) => showError(error.message))
            .finally(() => setLoading(false));
    }, [currentUser]);

    if (!currentUser) return <Navigate to="/login" replace />;

    return (
        <>
            <BackButton to="/listings" />
            <div className="col-12 col-lg-10 offset-lg-1">
                <h3 className="fw-bold mb-4">My Bookings</h3>

                {loading && (
                    <div className="text-center text-secondary my-5">
                        <i className="fa-solid fa-spinner fa-spin me-2"></i>
                        Loading bookings...
                    </div>
                )}

                {!loading && bookings.length === 0 && (
                    <div className="text-center text-secondary my-5">
                        <i className="fa-solid fa-calendar-xmark d-block fs-1 mb-3"></i>
                        No bookings yet.
                    </div>
                )}

                <div className="row g-3">
                    {bookings.map((booking) => (
                        <div className="col-12" key={booking._id}>
                            <Link to={`/listings/${booking.listing?._id}`} className="listing-link">
                                <div className="booking-list-item">
                                    <img
                                        src={booking.listing?.image?.url || fallbackImage}
                                        alt={booking.listing?.title || "Booking image"}
                                        className="booking-list-img"
                                    />
                                    <div className="booking-list-body">
                                        <h5 className="fw-bold mb-1">{booking.listing?.title}</h5>
                                        <small className="text-secondary">
                                            {booking.listing?.location}, {booking.listing?.country}
                                        </small>
                                        <div className="booking-dates mt-2">
                                            {formatDate(booking.checkIn)} to {formatDate(booking.checkOut)}
                                        </div>
                                        <div className="fw-semibold mt-1">
                                            {booking.guests} guest{booking.guests === 1 ? "" : "s"} · &#8377; {Number(booking.totalPrice || 0).toLocaleString("en-IN")}
                                        </div>
                                    </div>
                                </div>
                            </Link>
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
}

function formatDate(value) {
    return new Date(value).toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
    });
}
