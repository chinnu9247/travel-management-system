import { Link, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { api } from "../api";
import { BackButton } from "../components/Layout.jsx";

export default function NotificationsIndex({ currentUser, showError, refreshNotifications }) {
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(true);

    const loadNotifications = () => api.notifications()
        .then((data) => setNotifications(data.notifications || []))
        .catch((error) => showError(error.message))
        .finally(() => setLoading(false));

    useEffect(() => {
        if (!currentUser) return;
        loadNotifications();
    }, [currentUser]);

    if (!currentUser) return <Navigate to="/login" replace />;

    const handleMarkRead = async (notificationId) => {
        try {
            await api.markNotificationRead(notificationId);
            await loadNotifications();
            await refreshNotifications();
        } catch (error) {
            showError(error.message);
        }
    };

    const handleMarkAllRead = async () => {
        try {
            await api.markAllNotificationsRead();
            await loadNotifications();
            await refreshNotifications();
        } catch (error) {
            showError(error.message);
        }
    };

    const hasUnread = notifications.some((notification) => !notification.readAt);

    return (
        <>
            <BackButton to="/listings" />
            <div className="col-12 col-lg-10 offset-lg-1">
                <div className="d-flex justify-content-between align-items-center gap-3 mb-4">
                    <h3 className="fw-bold mb-0">Notifications</h3>
                    {hasUnread && (
                        <button type="button" className="btn btn-outline-dark btn-sm" onClick={handleMarkAllRead}>
                            Mark all read
                        </button>
                    )}
                </div>

                {loading && (
                    <div className="text-center text-secondary my-5">
                        <i className="fa-solid fa-spinner fa-spin me-2"></i>
                        Loading notifications...
                    </div>
                )}

                {!loading && notifications.length === 0 && (
                    <div className="text-center text-secondary my-5">
                        <i className="fa-regular fa-bell d-block fs-1 mb-3"></i>
                        No notifications yet.
                    </div>
                )}

                <div className="notification-list">
                    {notifications.map((notification) => (
                        <div className={`notification-item ${notification.readAt ? "" : "is-unread"}`} key={notification._id}>
                            <div className="notification-icon">
                                <i className={notification.type === "new-booking" ? "fa-solid fa-calendar-check" : "fa-solid fa-suitcase"}></i>
                            </div>
                            <div className="notification-body">
                                <Link to={notification.link || "/notifications"} className="notification-message">
                                    {notification.message}
                                </Link>
                                <div className="text-secondary small mt-1">{formatDateTime(notification.createdAt)}</div>
                            </div>
                            {!notification.readAt && (
                                <button type="button" className="btn btn-sm btn-outline-success" onClick={() => handleMarkRead(notification._id)}>
                                    Read
                                </button>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
}

function formatDateTime(value) {
    return new Date(value).toLocaleString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
    });
}
